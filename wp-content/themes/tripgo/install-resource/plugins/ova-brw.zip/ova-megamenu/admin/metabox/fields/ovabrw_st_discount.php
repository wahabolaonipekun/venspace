<table class="wrap_rt_discount">
	<tbody>
		<tr class="tr_rt_discount">						
		    <td width="23%">
		        <input 
		        	type="text" 
		        	class="ovabrw_rt_discount_price input_per_100" 
		        	placeholder="<?php esc_html_e('10', 'ova-brw'); ?>" 
		            name="ovabrw_st_discount[ovabrw_key][adult_price][]" 
		            autocomplete="off" />
		    </td>
		    <td width="23%">
		        <input 
		        	type="text" 
		        	class="ovabrw_rt_discount_price input_per_100" 
		        	placeholder="<?php esc_html_e('10', 'ova-brw'); ?>" 
		            name="ovabrw_st_discount[ovabrw_key][children_price][]" 
		            autocomplete="off" />
		    </td>
		    <td width="23%">
		        <input 
		        	type="text" 
		        	class="ovabrw_rt_discount_price input_per_100" 
		        	placeholder="<?php esc_html_e('10', 'ova-brw'); ?>" 
		            name="ovabrw_st_discount[ovabrw_key][baby_price][]" 
		            autocomplete="off" />
		    </td>
		    <td width="30%">
			    <input 
			    	type="text" 
			    	class="input_text short ovabrw_rt_discount_duration" 
			    	placeholder="<?php esc_html_e('1', 'ova-brw'); ?>" 
			    	name="ovabrw_st_discount[ovabrw_key][min][]" 
			    	autocomplete="off" />
			    <input 
			    	type="text" 
			    	class="input_text short ovabrw_rt_discount_duration" 
			    	placeholder="<?php esc_html_e('2', 'ova-brw'); ?>" 
			    	name="ovabrw_st_discount[ovabrw_key][max][]" 
			    	autocomplete="off" />
		    </td>
		    <td width="1%"><a href="#" class="button delete_discount">x</a></td>
		</tr>
	</tbody>
</table>
